#pragma once

VOID HookSkciValidateImage();
