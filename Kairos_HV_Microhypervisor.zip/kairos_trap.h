#pragma once
#include <ntddk.h>
VOID InjectKairosTrap(PVOID GuestContext);
