#pragma once
#include <ntddk.h>
BOOLEAN InitializeEpt();
