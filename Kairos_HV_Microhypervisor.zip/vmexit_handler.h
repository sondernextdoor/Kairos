#pragma once
#include <ntddk.h>
VOID HandleVmExit();
