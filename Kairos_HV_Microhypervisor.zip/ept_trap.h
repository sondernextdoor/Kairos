#pragma once
#include <ntddk.h>
VOID SetupEptTrapForPgRegion(PVOID PgContextAddress);
VOID HandleEptViolation(PVOID GuestRip, ULONG64 Gpa);
