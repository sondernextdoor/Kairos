// multicore.c - Launch VMX on all logical processors
#include <ntddk.h>
#include "vmx_core.h"

VOID LaunchHypervisorOnAllCores() {
    DebugLog("Launching Kairos-HV on all logical processors...");

    KAFFINITY activeProcs = KeQueryActiveProcessors();
    for (ULONG i = 0; i < KeQueryActiveProcessorCount(NULL); i++) {
        KeSetSystemAffinityThread((KAFFINITY)(1 << i));
        LaunchVmxOnCpu();
    }

    KeRevertToUserAffinityThread();
    DebugLog("Kairos-HV launched on all cores.");
}
