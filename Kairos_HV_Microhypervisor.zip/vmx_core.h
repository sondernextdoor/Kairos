#pragma once
#include <ntddk.h>
BOOLEAN LaunchVmxOnCpu();
