#include <ntddk.h>

NTSTATUS SpoofPlutonAttestation(PVOID TpmData, ULONG Size) {
    UNREFERENCED_PARAMETER(TpmData);
    UNREFERENCED_PARAMETER(Size);

    DebugLog("Faked Pluton attestation response sent.");
    return STATUS_SUCCESS;
}
